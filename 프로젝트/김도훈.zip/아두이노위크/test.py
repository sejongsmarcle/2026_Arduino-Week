import time
import serial
from pynput.mouse import Controller, Button
#pip install pyserial pynput

# =========================
# 설정값
# =========================
PORT = "COM8"      # 🔴 여기만 네 아두이노 포트로 바꿔
BAUD = 9600

CENTER = 512
DEADZONE = 60      # 손 떨림 방지(50~80 사이 추천)
SENS = 0.035       # 감도(0.02~0.08 사이에서 조절)
MAX_STEP = 35      # 한 프레임 최대 이동 제한(너무 튀는 것 방지)

# =========================
# 유틸
# =========================
def axis_to_delta(v: int) -> int:
    d = v - CENTER
    if abs(d) < DEADZONE:
        return 0

    # 선형 매핑 + 클램프
    delta = int(d * SENS)
    if delta > MAX_STEP:
        delta = MAX_STEP
    elif delta < -MAX_STEP:
        delta = -MAX_STEP
    return delta

# =========================
# 메인
# =========================
mouse = Controller()
ser = serial.Serial(PORT, BAUD, timeout=0.05)

# UNO는 시리얼 열 때 리셋되는 경우가 많아서 대기
time.sleep(2.0)

prev_btn1 = 0
prev_btn2 = 0

print("Running... (Ctrl+C to stop)")

try:
    while True:
        line = ser.readline().decode(errors="ignore").strip()
        if not line:
            continue

        # 기대 포맷: x,y,js,btn1,btn2
        parts = line.split(",")
        if len(parts) != 5:
            continue

        try:
            x = int(parts[0])
            y = int(parts[1])
            js = int(parts[2])
            btn1 = int(parts[3])
            btn2 = int(parts[4])
        except ValueError:
            continue

        dx = -axis_to_delta(x)
        dy = axis_to_delta(y)

        # 화면 좌표는 위로 갈수록 y가 줄어드는 경우가 많아서 -dy
        if dx != 0 or dy != 0:
            mouse.move(dx, -dy)

        # BTN1 (D4) → 우클릭 (누르는 동안 누르고, 떼면 해제)
        if btn1 == 1 and prev_btn1 == 0:
            mouse.press(Button.right)
        elif btn1 == 0 and prev_btn1 == 1:
            mouse.release(Button.right)

        # BTN2 (D7) → 좌클릭
        if btn2 == 1 and prev_btn2 == 0:
            mouse.press(Button.left)
        elif btn2 == 0 and prev_btn2 == 1:
            mouse.release(Button.left)

        prev_btn1 = btn1
        prev_btn2 = btn2

except KeyboardInterrupt:
    pass
finally:
    # 혹시 눌린 채 종료되는 것 방지
    try:
        mouse.release(Button.left)
        mouse.release(Button.right)
    except Exception:
        pass
    ser.close()
    print("Stopped.")
